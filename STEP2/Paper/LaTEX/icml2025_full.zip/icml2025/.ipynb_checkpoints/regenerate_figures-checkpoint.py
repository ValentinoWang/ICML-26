"""
Regenerate key figures with unified Times-like serif fonts (TeX Gyre / CMU).
All plots read existing CSV outputs; no experiments are rerun.
"""

from __future__ import annotations

import pathlib
from typing import Dict, List

import matplotlib.pyplot as plt
import numpy as np

ROOT = pathlib.Path(__file__).resolve().parents[3]
FIG_DIR = ROOT / "Paper" / "LaTEX" / "icml2025" / "Figure"

# Global font settings: Times-like serif for CVPR/ICCV style.
plt.rcParams.update(
    {
        "font.family": "serif",
        # Prefer Times; fall back to TeX Gyre Termes / CMU Serif if Times is unavailable.
        "font.serif": ["Times New Roman", "Times", "TeX Gyre Termes", "CMU Serif", "DejaVu Serif"],
        "mathtext.fontset": "cm",
    }
)


def read_csv(path: pathlib.Path) -> Dict[str, List[float]]:
    with path.open() as f:
        header = f.readline().strip().split(",")
        cols: Dict[str, List[float]] = {h: [] for h in header}
        for line in f:
            parts = line.strip().split(",")
            for h, v in zip(header, parts):
                cols[h].append(float(v))
    return cols


def plot_exp1_const():
    data = read_csv(ROOT / "exp1_bias_sources" / "results" / "exp1_1.1_const.csv")
    gens = np.array(data["generation"])
    methods = [
        ("No Filter", "no_filter_b0.5_mean", "no_filter_b0.5_std", "tab:red"),
        ("Standard Filter", "standard_filter_b0.5_mean", "standard_filter_b0.5_std", "tab:blue"),
        ("Ours", "ours_b0.5_mean", "ours_b0.5_std", "tab:green"),
    ]
    plt.figure(figsize=(6, 4))
    for name, m_mean, m_std, color in methods:
        mean = np.array(data[m_mean])
        std = np.array(data[m_std])
        ci = 1.96 * std / np.sqrt(8)
        plt.plot(gens, mean, label=name, color=color, linewidth=2)
        plt.fill_between(gens, mean - ci, mean + ci, color=color, alpha=0.15)
    plt.xlabel("Generation")
    plt.ylabel(r"$\|\theta_t - \theta^\ast\|_2$")
    plt.title("Hard Bias $|b|=0.5$")
    plt.grid(alpha=0.3)
    plt.legend()
    plt.tight_layout()
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    plt.savefig(FIG_DIR / "exp1_1.1_const.png", dpi=300)
    plt.close()


def plot_exp2_bias():
    data = read_csv(ROOT / "exp2_bias_sensitivity" / "results" / "exp2_2.1_bias_summary.csv")
    bias = np.array(data["bias"])
    plt.figure(figsize=(6, 4))
    for name, key, color in [
        ("No Filter", "no_filter_mean", "tab:red"),
        ("Standard Filter", "standard_filter_mean", "tab:blue"),
        ("Ours", "ours_mean", "tab:green"),
    ]:
        plt.plot(bias, data[key], marker="o", label=name, color=color, linewidth=2)
    plt.xlabel("Bias magnitude")
    plt.ylabel("Tail error")
    plt.title("Robustness to Bias Magnitude")
    plt.grid(alpha=0.3)
    plt.legend()
    plt.tight_layout()
    plt.savefig(FIG_DIR / "exp2_2.1_trajs_by_method.png", dpi=300)
    plt.close()


def plot_exp4_base():
    data = read_csv(ROOT / "exp4_bias_correction_visualization" / "results" / "exp4_4.1_base.csv")
    gens = np.array(data["generation"])
    cos = np.array(data["cos_to_minus_b_mean"])
    ess = np.array(data["ess_mean"])
    fig, ax1 = plt.subplots(figsize=(6, 4))
    ax1.plot(gens, cos, color="tab:green", linewidth=2, label=r"$\cos(\Delta\phi, -b)$")
    ax1.fill_between(gens, cos - data["cos_to_minus_b_std"], cos + data["cos_to_minus_b_std"], color="tab:green", alpha=0.15)
    ax1.set_xlabel("Generation")
    ax1.set_ylabel("Cosine to $-b$", color="tab:green")
    ax1.tick_params(axis="y", labelcolor="tab:green")
    ax1.grid(alpha=0.3)

    ax2 = ax1.twinx()
    ax2.plot(gens, ess, color="tab:blue", linewidth=2, linestyle="--", label="ESS")
    ax2.set_ylabel("Effective Sample Size", color="tab:blue")
    ax2.tick_params(axis="y", labelcolor="tab:blue")

    lines, labels = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines + lines2, labels + labels2, loc="lower right")
    fig.tight_layout()
    plt.savefig(FIG_DIR / "exp4_4.1_base.png", dpi=300)
    plt.close(fig)


def plot_exp5_tail_vs_dim():
    data = read_csv(ROOT / "exp5_high_dim_scalability" / "results" / "exp5_tail_summary.csv")
    dims = np.array(data["dim"])
    plt.figure(figsize=(6, 4))
    for name, key, color in [
        ("No Filter", "no_filter_mean", "tab:red"),
        ("Standard Filter", "mlp_filter_mean", "tab:gray"),
        ("MLP+Corr", "mlp_correction_mean", "tab:orange"),
        ("Ours", "ours_mean", "tab:green"),
    ]:
        plt.semilogy(dims, data[key], marker="o", label=name, color=color, linewidth=2)
    plt.xlabel("Dimension")
    plt.ylabel("Tail error")
    plt.title("Tail Error vs Dimension")
    plt.grid(alpha=0.3, which="both")
    plt.legend()
    plt.tight_layout()
    plt.savefig(FIG_DIR / "exp5_tail_vs_dim.png", dpi=300)
    plt.close()


def plot_exp5_trajs():
    files = {
        "d=50": ROOT / "exp5_high_dim_scalability" / "results" / "exp5_dim50_trajectories.csv",
        "d=100": ROOT / "exp5_high_dim_scalability" / "results" / "exp5_dim100_trajectories.csv",
        "d=500": ROOT / "exp5_high_dim_scalability" / "results" / "exp5_dim500_trajectories.csv",
    }
    fig, axes = plt.subplots(1, 3, figsize=(12, 4), sharey=True)
    for ax, (title, path) in zip(axes, files.items()):
        data = read_csv(path)
        gens = np.array(data["generation"])
        for name, key, color in [
            ("No Filter", "no_filter_mean", "tab:red"),
            ("Standard Filter", "mlp_filter_mean", "tab:gray"),
            ("MLP+Corr", "mlp_correction_mean", "tab:orange"),
            ("Ours", "ours_mean", "tab:green"),
        ]:
            ax.plot(gens, data[key], label=name, linewidth=2, color=color)
        ax.set_title(title)
        ax.set_xlabel("Generation")
        ax.grid(alpha=0.3)
    axes[0].set_ylabel(r"$\|\theta_t - \theta^\ast\|_2$")
    axes[-1].legend(loc="upper right")
    fig.tight_layout()
    plt.savefig(FIG_DIR / "exp5_trajs_by_dim.png", dpi=300)
    plt.close(fig)


def plot_exp6_trajs_and_tail():
    traj_files = {
        "Bayes n=5": ROOT / "exp6_arch_ablation" / "results" / "exp6_bayes_trajectories.csv",
        "Ridge α=10": ROOT / "exp6_arch_ablation" / "results" / "exp6_ridge_trajectories.csv",
        "Complex bias": ROOT / "exp6_arch_ablation" / "results" / "exp6_complex_trajectories.csv",
    }
    fig, axes = plt.subplots(1, 3, figsize=(12, 4), sharey=True)
    for ax, (title, path) in zip(axes, traj_files.items()):
        data = read_csv(path)
        gens = np.array(data["generation"])
        for name, key, color in [
            ("Weight-only", "only_weight_mean", "tab:red"),
            ("Corr-only", "only_correction_mean", "tab:orange"),
            ("MLP+Corr", "mlp_correction_mean", "tab:blue"),
            ("Ours", "ours_full_mean", "tab:green"),
        ]:
            ax.plot(gens, data[key], label=name, linewidth=2, color=color)
        ax.set_title(title)
        ax.set_xlabel("Generation")
        ax.grid(alpha=0.3)
    axes[0].set_ylabel(r"$\|\theta_t - \theta^\ast\|_2$")
    axes[-1].legend(loc="upper right")
    fig.tight_layout()
    plt.savefig(FIG_DIR / "exp6_trajs.png", dpi=300)
    plt.close(fig)

    # Tail bar
    tail_files = [
        ROOT / "exp6_arch_ablation" / "results" / "exp6_bayes_tail_summary.csv",
        ROOT / "exp6_arch_ablation" / "results" / "exp6_ridge_tail_summary.csv",
        ROOT / "exp6_arch_ablation" / "results" / "exp6_complex_tail_summary.csv",
    ]
    labels = ["Bayes n=5", "Ridge α=10", "Complex"]
    methods = [
        ("Weight-only", "only_weight_mean", "tab:red"),
        ("Corr-only", "only_correction_mean", "tab:orange"),
        ("MLP+Corr", "mlp_correction_mean", "tab:blue"),
        ("Ours", "ours_full_mean", "tab:green"),
    ]
    x = np.arange(len(labels))
    width = 0.18
    plt.figure(figsize=(7, 4))
    for i, (m_name, key, color) in enumerate(methods):
        vals = []
        for f in tail_files:
            vals.append(read_csv(f)[key][0])
        plt.bar(x + (i - 1.5) * width, vals, width, label=m_name, color=color)
    plt.xticks(x, labels)
    plt.ylabel("Tail error")
    plt.title("Ablation tail errors")
    plt.grid(axis="y", alpha=0.3)
    plt.legend()
    plt.tight_layout()
    plt.savefig(FIG_DIR / "exp6_tail_bar.png", dpi=300)
    plt.close()


def plot_exp7_curves():
    data = read_csv(ROOT / "exp7_recursive_regression" / "results" / "exp7_trajectories.csv")
    gens = np.array(data["generation"])
    plt.figure(figsize=(6, 4))
    for name, key, color in [
        ("No Filter", "no_filter_mse_mean", "tab:red"),
        ("Ours", "ours_mse_mean", "tab:green"),
    ]:
        plt.plot(gens, data[key], label=name, linewidth=2, color=color)
    plt.xlabel("Generation")
    plt.ylabel("Test MSE")
    plt.title("Recursive Regression (California Housing)")
    plt.grid(alpha=0.3)
    plt.legend()
    plt.tight_layout()
    plt.savefig(FIG_DIR / "exp7_curves.png", dpi=300)
    plt.close()


def plot_exp8_curves():
    data = read_csv(ROOT / "exp8_mnist_recursive" / "results" / "exp8_trajectories.csv")
    gens = np.array(data["generation"])
    seeds = 3  # runtime_exp8 shows 3 seeds
    plt.figure(figsize=(6, 4))
    for name, mean_key, std_key, color in [
        ("No Filter", "no_filter_mse_mean", "no_filter_mse_std", "tab:red"),
        ("MLP (w)", "mlp_filter_mse_mean", "mlp_filter_mse_std", "tab:blue"),
        ("TENT", "tent_mse_mean", "tent_mse_std", "tab:purple"),
        ("Ours", "ours_mse_mean", "ours_mse_std", "tab:green"),
    ]:
        mean = np.array(data[mean_key])
        std = np.array(data[std_key])
        ci = 1.96 * std / np.sqrt(seeds)
        plt.semilogy(gens, mean, label=name, linewidth=2, color=color)
        plt.fill_between(gens, mean - ci, mean + ci, color=color, alpha=0.15)

    # Bracket/annotation for collapsed baselines near tail (shade box)
    ax = plt.gca()
    x_start = gens[-40] if len(gens) > 40 else gens[max(0, len(gens) // 2)]
    x_end = gens[-1]
    baseline_last = [
        data["no_filter_mse_mean"][-1],
        data["mlp_filter_mse_mean"][-1],
        data["tent_mse_mean"][-1],
    ]
    y_low = min(baseline_last) * 0.85
    y_high = max(baseline_last) * 1.15
    rect = plt.Rectangle(
        (x_start, y_low),
        x_end - x_start,
        y_high - y_low,
        fill=True,
        facecolor="gray",
        alpha=0.08,
        edgecolor="black",
        linewidth=1.2,
    )
    ax.add_patch(rect)
    ax.text(
        x_start,
        y_low * 1.05,
        "Collapsed baselines (≈3×10$^{-2}$):\nNo / TENT / MLP(w)",
        ha="left",
        va="bottom",
        fontsize=6,
        color="black",
    )
    plt.xlabel("Generation")
    plt.ylabel("Test MSE")
    plt.title("MNIST Rotational Drift")
    plt.grid(alpha=0.3, which="both")
    plt.legend()
    plt.tight_layout()
    plt.savefig(FIG_DIR / "exp8_curves.png", dpi=300)
    plt.close()


def main():
    plot_exp1_const()
    plot_exp2_bias()
    plot_exp4_base()
    plot_exp5_tail_vs_dim()
    plot_exp5_trajs()
    plot_exp6_trajs_and_tail()
    plot_exp7_curves()
    plot_exp8_curves()


if __name__ == "__main__":
    main()
